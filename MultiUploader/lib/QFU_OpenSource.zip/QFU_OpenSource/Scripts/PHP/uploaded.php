Files were uploaded successfully!<br />
You can check them <a href = "uploaded">here</a> <br />

<?
$AdditionalStringVariable = $_POST["AdditionalStringVariable"];
echo 'AdditionalStringVariable = '.$AdditionalStringVariable;
?>
